package com.toopan2d.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private GameView gameView;

    static {
        System.loadLibrary("toopan2d");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Keep screen on and hide UI
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        // Use simple Java game instead of C/OpenGL
        SimpleGameView simpleGameView = new SimpleGameView(this);
        setContentView(simpleGameView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // No need for onResume/onPause with simple game
    }

    @Override
    protected void onPause() {
        super.onPause();
        // No need for onResume/onPause with simple game
    }

    public native void nativeInit();
    public native void nativeResize(int width, int height);
    public native void nativeRender();
    public native void nativeTouch(float x, float y, int action);
}