package com.toopan2d.game;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameView extends GLSurfaceView {
    private GameRenderer renderer;
    private MainActivity activity;

    public GameView(Context context) {
        super(context);
        activity = (MainActivity) context;
        
        setEGLContextClientVersion(2);
        renderer = new GameRenderer();
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        int action = event.getAction();
        
        queueEvent(() -> activity.nativeTouch(x, y, action));
        return true;
    }

    private class GameRenderer implements GLSurfaceView.Renderer {
        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            activity.nativeInit();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            activity.nativeResize(width, height);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            activity.nativeRender();
        }
    }
}