package com.toopan2d.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class SimpleGameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    private Thread gameThread;
    private boolean isPlaying = false;
    private SurfaceHolder surfaceHolder;
    private Paint paint;
    
    // Game objects
    private float ballX = 400, ballY = 300;
    private float ballVelX = 5, ballVelY = 3;
    private float ballRadius = 20;
    
    private float[] playerX = {200, 300, 400, 500, 600, 700};
    private float[] playerY = {200, 400, 600, 200, 400, 600};
    private float playerRadius = 30;
    private int selectedPlayer = -1;
    
    private int scoreA = 0, scoreB = 0;
    private float fieldWidth = 800, fieldHeight = 600;

    public SimpleGameView(Context context) {
        super(context);
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
        paint = new Paint();
        setFocusable(true);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        isPlaying = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        isPlaying = false;
        while (retry) {
            try {
                gameThread.join();
                retry = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        fieldWidth = width;
        fieldHeight = height;
    }

    @Override
    public void run() {
        while (isPlaying) {
            update();
            draw();
            try {
                Thread.sleep(16); // ~60 FPS
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void update() {
        // Update ball
        ballX += ballVelX;
        ballY += ballVelY;
        
        // Ball collision with walls
        if (ballX <= ballRadius || ballX >= fieldWidth - ballRadius) {
            ballVelX = -ballVelX;
        }
        if (ballY <= ballRadius || ballY >= fieldHeight - ballRadius) {
            ballVelY = -ballVelY;
        }
        
        // Ball collision with players
        for (int i = 0; i < 6; i++) {
            float dx = ballX - playerX[i];
            float dy = ballY - playerY[i];
            float distance = (float) Math.sqrt(dx * dx + dy * dy);
            
            if (distance < ballRadius + playerRadius) {
                // Simple collision response
                ballVelX = dx / distance * 8;
                ballVelY = dy / distance * 8;
            }
        }
        
        // Check goals
        if (ballX < 50 && ballY > fieldHeight/2 - 100 && ballY < fieldHeight/2 + 100) {
            scoreB++;
            resetBall();
        }
        if (ballX > fieldWidth - 50 && ballY > fieldHeight/2 - 100 && ballY < fieldHeight/2 + 100) {
            scoreA++;
            resetBall();
        }
    }

    private void resetBall() {
        ballX = fieldWidth / 2;
        ballY = fieldHeight / 2;
        ballVelX = (Math.random() > 0.5 ? 1 : -1) * 5;
        ballVelY = (Math.random() > 0.5 ? 1 : -1) * 3;
    }

    private void draw() {
        if (surfaceHolder.getSurface().isValid()) {
            Canvas canvas = surfaceHolder.lockCanvas();
            
            // Clear screen
            canvas.drawColor(Color.GREEN);
            
            // Draw field lines
            paint.setColor(Color.WHITE);
            paint.setStrokeWidth(5);
            canvas.drawRect(50, 50, fieldWidth - 50, fieldHeight - 50, paint);
            canvas.drawLine(fieldWidth/2, 50, fieldWidth/2, fieldHeight - 50, paint);
            canvas.drawCircle(fieldWidth/2, fieldHeight/2, 100, paint);
            
            // Draw goals
            paint.setColor(Color.YELLOW);
            canvas.drawRect(0, fieldHeight/2 - 100, 50, fieldHeight/2 + 100, paint);
            canvas.drawRect(fieldWidth - 50, fieldHeight/2 - 100, fieldWidth, fieldHeight/2 + 100, paint);
            
            // Draw players
            for (int i = 0; i < 6; i++) {
                if (i < 3) {
                    paint.setColor(Color.RED); // Team A
                } else {
                    paint.setColor(Color.BLUE); // Team B
                }
                canvas.drawCircle(playerX[i], playerY[i], playerRadius, paint);
            }
            
            // Draw ball
            paint.setColor(Color.WHITE);
            canvas.drawCircle(ballX, ballY, ballRadius, paint);
            
            // Draw score
            paint.setColor(Color.WHITE);
            paint.setTextSize(50);
            canvas.drawText("Score: " + scoreA + " - " + scoreB, 100, 100, paint);
            
            surfaceHolder.unlockCanvasAndPost(canvas);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();
        
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            // Find nearest player (only team A - first 3)
            float minDistance = Float.MAX_VALUE;
            selectedPlayer = -1;
            
            for (int i = 0; i < 3; i++) {
                float dx = touchX - playerX[i];
                float dy = touchY - playerY[i];
                float distance = (float) Math.sqrt(dx * dx + dy * dy);
                
                if (distance < minDistance && distance < 100) {
                    minDistance = distance;
                    selectedPlayer = i;
                }
            }
        } else if (event.getAction() == MotionEvent.ACTION_MOVE && selectedPlayer >= 0) {
            // Move selected player towards touch
            float dx = touchX - playerX[selectedPlayer];
            float dy = touchY - playerY[selectedPlayer];
            float distance = (float) Math.sqrt(dx * dx + dy * dy);
            
            if (distance > 10) {
                playerX[selectedPlayer] += (dx / distance) * 5;
                playerY[selectedPlayer] += (dy / distance) * 5;
                
                // Keep in bounds
                if (playerX[selectedPlayer] < playerRadius) playerX[selectedPlayer] = playerRadius;
                if (playerX[selectedPlayer] > fieldWidth - playerRadius) playerX[selectedPlayer] = fieldWidth - playerRadius;
                if (playerY[selectedPlayer] < playerRadius) playerY[selectedPlayer] = playerRadius;
                if (playerY[selectedPlayer] > fieldHeight - playerRadius) playerY[selectedPlayer] = fieldHeight - playerRadius;
            }
        } else if (event.getAction() == MotionEvent.ACTION_UP) {
            selectedPlayer = -1;
        }
        
        return true;
    }
}